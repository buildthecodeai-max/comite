<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/src/bootstrap.php';

use CommitteeManager\Auth;
use CommitteeManager\DataRepository;
use CommitteeManager\Http;
use CommitteeManager\PasswordResetService;

header('Access-Control-Allow-Origin: ' . ($_SERVER['HTTP_ORIGIN'] ?? '*'));
header('Access-Control-Allow-Credentials: true');
header('Access-Control-Allow-Headers: Content-Type');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');

if (Http::method() === 'OPTIONS') {
    http_response_code(204);
    exit;
}

try {
    $repo = new DataRepository();
    $action = Http::action();

    if (Http::method() === 'GET' && $action === 'session') {
        $user = Auth::user();
        if ($user === null) {
            Http::json(['loggedIn' => false]);
        }

        Http::json([
            'loggedIn' => true,
            'user' => [
                'role' => $user['role'],
                'memberId' => $user['memberId'],
            ],
        ]);
    }

    if (Http::method() !== 'POST') {
        Http::json(['ok' => false, 'error' => 'Method not allowed'], 405);
    }

    $body = Http::readJsonBody();

    switch ($action) {
        case 'login':
            $role = (string) ($body['role'] ?? '');
            if ($role === 'admin') {
                $username = trim((string) ($body['username'] ?? ''));
                $password = (string) ($body['password'] ?? '');
                if ($repo->getAdminUsername() === null) {
                    Http::json(['ok' => false, 'error' => 'System not initialized. Import sql/committee_manager.sql or run php scripts/seed.php'], 503);
                }
                if (!Auth::loginAdmin($username, $password, $repo)) {
                    Http::json(['ok' => false, 'error' => 'Invalid admin credentials'], 401);
                }
                Http::json([
                    'ok' => true,
                    'user' => ['role' => 'admin', 'memberId' => null],
                ]);
            }

            if ($role === 'user') {
                $name = trim((string) ($body['name'] ?? ''));
                $pin = trim((string) ($body['pin'] ?? ''));
                $memberId = (int) ($body['memberId'] ?? 0);

                // Prefer private name+PIN login. memberId is accepted only as a legacy fallback
                // after the server resolves the name itself.
                if ($name !== '') {
                    $resolved = $repo->findActiveMemberIdByName($name);
                    if ($resolved === null) {
                        Http::json(['ok' => false, 'error' => 'Name or PIN is incorrect'], 401);
                    }
                    $memberId = $resolved;
                }

                if ($memberId <= 0 || $pin === '') {
                    Http::json(['ok' => false, 'error' => 'Name and PIN are required'], 400);
                }
                if (!Auth::loginMember($memberId, $pin, $repo)) {
                    Http::json(['ok' => false, 'error' => 'Name or PIN is incorrect'], 401);
                }
                Http::json([
                    'ok' => true,
                    'user' => ['role' => 'user', 'memberId' => $memberId],
                ]);
            }

            Http::json(['ok' => false, 'error' => 'Invalid role'], 400);

        case 'logout':
            Auth::logout();
            Http::json(['ok' => true]);

        case 'change-admin-pass':
            Auth::requireAdmin();
            $old = (string) ($body['oldPassword'] ?? '');
            $new = (string) ($body['newPassword'] ?? '');
            if (strlen($new) < 4) {
                Http::json(['ok' => false, 'error' => 'Password must be at least 4 characters'], 400);
            }
            if (!$repo->verifyAdminPassword($old)) {
                Http::json(['ok' => false, 'error' => 'Wrong password'], 401);
            }
            $repo->updateAdminPassword($new);
            Http::json(['ok' => true]);

        case 'change-member-pin':
            $user = Auth::requireLogin();
            if ($user['role'] !== 'user' || empty($user['memberId'])) {
                Http::json(['ok' => false, 'error' => 'Member access required'], 403);
            }
            $old = trim((string) ($body['oldPin'] ?? ''));
            $new = trim((string) ($body['newPin'] ?? ''));
            if (strlen($new) !== 4 || !ctype_digit($new)) {
                Http::json(['ok' => false, 'error' => 'PIN must be 4 digits'], 400);
            }
            if (!$repo->verifyMemberPin((int) $user['memberId'], $old)) {
                Http::json(['ok' => false, 'error' => 'Wrong PIN'], 401);
            }
            $current = $repo->loadAll();
            $saved = $repo->saveMemberSelf((int) $user['memberId'], [
                'members' => [['id' => $user['memberId'], 'pin' => $new]],
                'updatedAt' => (int) (microtime(true) * 1000),
            ], $current);
            Http::json(['ok' => true, 'data' => $saved]);

        case 'forgot-admin-password':
            $username = trim((string) ($body['username'] ?? ''));
            $email = trim((string) ($body['email'] ?? ''));
            if ($username === '' || $email === '') {
                Http::json(['ok' => false, 'error' => 'Username and email are required'], 400);
            }
            $result = (new PasswordResetService())->requestAdminReset($username, $email, $repo);
            Http::json($result);

        case 'reset-admin-password':
            $username = trim((string) ($body['username'] ?? ''));
            $email = trim((string) ($body['email'] ?? ''));
            $code = trim((string) ($body['code'] ?? ''));
            $newPassword = (string) ($body['newPassword'] ?? '');
            if ($username === '' || $email === '' || $code === '' || $newPassword === '') {
                Http::json(['ok' => false, 'error' => 'All fields are required'], 400);
            }
            (new PasswordResetService())->resetAdminPassword($username, $email, $code, $newPassword, $repo);
            Http::json(['ok' => true, 'message' => 'Password reset successfully. You can log in with your new password.']);

        default:
            Http::json(['ok' => false, 'error' => 'Unknown action'], 404);
    }
} catch (\Throwable $e) {
    $message = $e->getMessage();
    if (stripos($message, 'Database connection failed') !== false || stripos($message, 'SQLSTATE') !== false) {
        $message = 'Database connection failed. Check .env DB_HOST/DB_NAME/DB_USER/DB_PASS on the server. Open /api/health.php for details.';
    }
    Http::json(['ok' => false, 'error' => $message], 500);
}
