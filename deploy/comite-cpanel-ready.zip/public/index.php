<?php

declare(strict_types=1);

$template = dirname(__DIR__) . '/templates/app.html';
if (!is_file($template)) {
    http_response_code(500);
    echo 'Application template missing.';
    exit;
}

readfile($template);
